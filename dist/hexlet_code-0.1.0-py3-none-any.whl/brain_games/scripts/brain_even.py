#!/usr/bin/env python3

from brain_games.games.even_game import guess_even_number


def main():
    guess_even_number()


if __name__ == '__main__':
    main()
