### Hexlet tests and linter status:
[![Actions Status](https://github.com/DolAndd/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/DolAndd/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/6f3c984c8220c448a1e3/maintainability)](https://codeclimate.com/github/DolAndd/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/siwijoI9AsJmLwJWMhbx2pWnt.svg)](https://asciinema.org/a/siwijoI9AsJmLwJWMhbx2pWnt)
[![asciicast](https://asciinema.org/a/iaiviAVP1vxMsjWPBDvBAI6F9.svg)](https://asciinema.org/a/iaiviAVP1vxMsjWPBDvBAI6F9)
[![asciicast](https://asciinema.org/a/WEsRtij7FIe0i2d2N2wlw3ruv.svg)](https://asciinema.org/a/WEsRtij7FIe0i2d2N2wlw3ruv)
